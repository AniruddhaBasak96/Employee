var content='<div class="ui-page " deviceName="iphone15promax" deviceType="mobile" deviceWidth="430" deviceHeight="932">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/f39803f7-df02-4169-93eb-7547fb8c961a/style-1722338289891.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-f0878c93-0cf0-4555-b804-a260ad690c53" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Screen 3"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/f0878c93-0cf0-4555-b804-a260ad690c53/style-1722338289891.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/f0878c93-0cf0-4555-b804-a260ad690c53/fonts-1722338289891.css" />\
      <div class="freeLayout">\
      <div id="s-Date_1" class="date firer commentable non-processed" customid="Date 1" value="" format="MM/dd/yyyy"  datasizewidth="300.00px" datasizeheight="39.41px" dataX="65.00" dataY="466.00" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="date"  tabindex="-1"  /></div></div></div></div></div>\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="430.00px" datasizeheight="124.00px" datasizewidthpx="430.0000000000002" datasizeheightpx="124.00000000000014" dataX="-0.00" dataY="73.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_text_1" class="text firer commentable non-processed" customid="Input text 1"  datasizewidth="401.50px" datasizeheight="45.00px" dataX="-0.00" dataY="87.00" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Reetam&#039;s Leave dashboard"/></div></div>  </div></div></div>\
      <div id="shapewrapper-s-Ellipse_1" customid="Ellipse 1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="131.00px" datasizeheight="126.31px" datasizewidthpx="130.99999999999997" datasizeheightpx="126.3079633081428" dataX="19.00" dataY="132.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_1)">\
                          <ellipse id="s-Ellipse_1" class="ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 1" cx="65.49999999999999" cy="63.1539816540714" rx="65.49999999999999" ry="63.1539816540714">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                          <ellipse cx="65.49999999999999" cy="63.1539816540714" rx="65.49999999999999" ry="63.1539816540714">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_1" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_1_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image 3"   datasizewidth="79.00px" datasizeheight="72.49px" dataX="337.00" dataY="122.66"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/7709f4d9-c2cf-47e7-bcc7-1fd0e1c9f1cf.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Category_2" class="dropdown firer commentable non-processed" customid="Select list"    datasizewidth="300.00px" datasizeheight="40.00px" dataX="65.00" dataY="392.76"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Choose leave type</div></div></div></div></div><select id="s-Category_2-options" class="s-f0878c93-0cf0-4555-b804-a260ad690c53 dropdown-options" ><option selected="selected" class="option">Choose leave type</option>\
      <option  class="option">Annual leave</option>\
      <option  class="option">Sick leave</option>\
      <option  class="option">Optional leave</option>\
      <option  class="option">Other</option></select></div>\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Filled button"   datasizewidth="145.00px" datasizeheight="50.00px" dataX="128.25" dataY="556.67" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Submit leave</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer click commentable non-processed" customid="Home"   datasizewidth="43.50px" datasizeheight="41.82px" dataX="171.50" dataY="862.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="43.49802017211914" height="41.81520080566406" viewBox="171.5019793510437 861.9999998734127 43.49802017211914 41.81520080566406" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-f0878" d="M171.5019793510437 881.7428319144094 C171.5019793510437 882.7586980492556 172.21330852067953 883.63766395923 173.35144291056466 883.63766395923 C173.9027248260483 883.63766395923 174.40065090315525 883.3056355574503 174.84524140286348 882.9149341168248 L176.87253749599552 881.0396604581065 L176.87253749599552 899.2054653080374 C176.87253749599552 902.0961600147923 178.45526238558887 903.8151997254024 181.17612262987583 903.8151997254024 L205.23692935906485 903.8151997254024 C207.94012588976096 903.8151997254024 209.54059650166568 902.0961600147923 209.54059650166568 899.2054653080374 L209.54059650166568 880.942095309922 L211.67462163810376 882.9149341168248 C212.10134870886645 883.3056355574503 212.59929408214293 883.63766395923 213.15065511192168 883.63766395923 C214.19976469404764 883.63766395923 215.0 882.9149341168248 215.0 881.7819465671529 C215.0 881.1178897635936 214.76893222907177 880.5905085220401 214.30639532688906 880.160694548132 L209.54059650166568 875.7463087316188 L209.54059650166568 867.4252730561425 C209.54059650166568 866.5462848918276 209.02484462314382 865.9993706977039 208.22460931719147 865.9993706977039 L205.7704877428321 865.9993706977039 C204.98805894212515 865.9993706977039 204.4545005583579 866.5462848918276 204.4545005583579 867.4252730561425 L204.4545005583579 871.0584128315187 L195.793955156051 863.0694267524322 C194.2469021302655 861.6435243939935 192.29072785879958 861.6435243939935 190.743472223234 863.0694267524322 L172.21330852067953 880.160694548132 C171.7331474620535 880.5905085220401 171.5019793510437 881.1765606829783 171.5019793510437 881.7428319144094 Z M198.37251386849715 887.1339692130254 C198.37251386849715 886.2158886503074 197.83915616489304 885.630059032774 197.0033117076838 885.630059032774 L189.53431828138127 885.630059032774 C188.69847189455507 885.630059032774 188.1471089351594 886.2158886503074 188.1471089351594 887.1339692130254 L188.1471089351594 899.9281930309817 L182.1186382418825 899.9281930309817 C181.01605511474565 899.9281930309817 180.41143762186329 899.244357417376 180.41143762186329 898.0138068389807 L180.41143762186329 877.7778205773674 L192.4863852290171 866.643960251984 C192.98433253191052 866.1751640916449 193.55329745715454 866.1751640916449 194.05124476004798 866.643960251984 L205.98394968867808 877.6604766191368 L205.98394968867808 898.0138068389807 C205.98394968867808 899.244357417376 205.37917300239707 899.9281930309817 204.2766477637688 899.9281930309817 L198.37251386849715 899.9281930309817 L198.37251386849715 887.1339692130254 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-f0878" fill="#8E8E93" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer click commentable non-processed" customid="Arrow Back"   datasizewidth="48.00px" datasizeheight="36.82px" dataX="28.50" dataY="862.00"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="48.0" height="36.81520080566406" viewBox="28.50000000000003 861.9999999999998 48.0 36.81520080566406" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-f0878" d="M76.50000000000009 878.1066498798634 L39.98999977111821 878.1066498798634 L56.7600002288819 865.2443391247037 L52.50000000000006 861.9999999999998 L28.50000000000003 880.4075998627011 L52.50000000000006 898.8151997254025 L56.72999989986426 895.5708603264039 L39.98999977111821 882.7085498455389 L76.50000000000009 882.7085498455389 L76.50000000000009 878.1066498798634 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-f0878" fill="#7D7D7D" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;