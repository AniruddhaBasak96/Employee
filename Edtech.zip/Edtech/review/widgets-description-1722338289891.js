	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Button_1", "dc61f332-3058-4eb1-b52e-09fd6c2ae2f9"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "dc61f332-3058-4eb1-b52e-09fd6c2ae2f9"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_31", "dc61f332-3058-4eb1-b52e-09fd6c2ae2f9"]] = ""; 

			widgets.rootWidgetMap[["s-Path_31", "dc61f332-3058-4eb1-b52e-09fd6c2ae2f9"]] = ["Home", "s-Path_31"]; 

	widgets.descriptionMap[["s-Path_117", "dc61f332-3058-4eb1-b52e-09fd6c2ae2f9"]] = ""; 

			widgets.rootWidgetMap[["s-Path_117", "dc61f332-3058-4eb1-b52e-09fd6c2ae2f9"]] = ["Arrow back", "s-Path_117"]; 

	widgets.descriptionMap[["s-Path_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Browser bottom", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Cell_67", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_67", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Browser bottom", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Browser bottom", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Cell_68", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_68", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Browser bottom", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Union_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Union_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Browser bottom", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Cell_69", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_69", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Browser bottom", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_14", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_14", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Browser bottom", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Cell_70", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_70", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Browser bottom", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Browser bottom", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Cell_71", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Cell_71", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Browser bottom", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Panel_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Panel_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Browser bottom", "s-Dynamic_Panel_1"]; 

	widgets.descriptionMap[["s-Path_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Status bar", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_9", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Status bar", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Status bar", "s-Group_4"]; 

	widgets.descriptionMap[["s-Path_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Status bar", "s-Group_4"]; 

	widgets.descriptionMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Title Button", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-pieChart", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-pieChart", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Pie Chart", "s-pieChart"]; 

	widgets.descriptionMap[["s-Rectangle_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Page control 2", "s-Group_2"]; 

	widgets.descriptionMap[["s-Ellipse_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Page control 2", "s-Group_2"]; 

	widgets.descriptionMap[["s-Ellipse_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Page control 2", "s-Group_2"]; 

	widgets.descriptionMap[["s-Ellipse_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Page control 2", "s-Group_2"]; 

	widgets.descriptionMap[["s-Category_2", "f0878c93-0cf0-4555-b804-a260ad690c53"]] = ""; 

			widgets.rootWidgetMap[["s-Category_2", "f0878c93-0cf0-4555-b804-a260ad690c53"]] = ["Select list", "s-Category_2"]; 

	widgets.descriptionMap[["s-Button_1", "f0878c93-0cf0-4555-b804-a260ad690c53"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "f0878c93-0cf0-4555-b804-a260ad690c53"]] = ["Button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Path_1", "f0878c93-0cf0-4555-b804-a260ad690c53"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "f0878c93-0cf0-4555-b804-a260ad690c53"]] = ["Home", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_2", "f0878c93-0cf0-4555-b804-a260ad690c53"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "f0878c93-0cf0-4555-b804-a260ad690c53"]] = ["Arrow back", "s-Path_2"]; 

	