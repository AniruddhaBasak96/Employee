(function(window, undefined) {

  var jimLinks = {
    "dc61f332-3058-4eb1-b52e-09fd6c2ae2f9" : {
      "Button_1" : [
        "f0878c93-0cf0-4555-b804-a260ad690c53"
      ],
      "Path_31" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Path_117" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Rectangle_3" : [
        "dc61f332-3058-4eb1-b52e-09fd6c2ae2f9"
      ]
    },
    "f0878c93-0cf0-4555-b804-a260ad690c53" : {
      "Path_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724",
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Path_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724",
        "dc61f332-3058-4eb1-b52e-09fd6c2ae2f9"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);